package oving9;

public interface ListListener {
	public void listChanged(ObservableList list, int lowestIndex,  int highestIndex);
}
