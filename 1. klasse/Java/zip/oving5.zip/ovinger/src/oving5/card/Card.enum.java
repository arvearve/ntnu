package oving5.card;



public class Card_enum {
	public enum Face {
		ACE(1), TWO(2), THREE(3), FOUR(4), FIVE(5), SIX(6), SEVEN(7), EIGHT(8), NINE(
				9), TEN(10), JACK(11), QUEEN(12), KING(13);
		private int value;
		private Face(int value){
			this.value = value;
		}
	}

	public enum Suit {
		CLUBS('C'), DIAMONDS('D'), HEARTS('H'), SPADES('S');
		private char suit;
		private Suit(char c){
			this.suit = c;
		}
	}

	private final Face face;
	private final Suit suit;

	public Card(String suit, Integer face) {
		this.suit = Suit.valueOf(suit);
		this.face = Face.valueOf(face.toString());
	}

}
